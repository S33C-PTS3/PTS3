/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testprojectairhockey.domain;

/**
 *
 * @author Sasa2905
 * Enum for SideNames and the Sides Bats.
 */
public enum SideName {
    LEFT,RIGHT,BOTTOM,BATLEFT,BATRIGHT,BATBOTTOM;
}
