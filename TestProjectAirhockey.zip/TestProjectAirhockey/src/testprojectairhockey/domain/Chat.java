/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testprojectairhockey.domain;

import java.util.List;

/**
 *
 * @author Eric
 */
public class Chat {
    
    private List<Message> messages;
    
    /**
     * Creates a new instance of the Chat class
     */
    public Chat()
    {
        
    }
    
    /**
     * gets the list of messages
     * @return list of messages
     */
    public List<Message> getMessages()
    {
        return null;
    }
    
    /**
     * adds a message to the list of messages
     * @param message
     * @return true/false
     */
    public boolean addMessage(Message message)
    {
        return false;
    }
    
    
}
